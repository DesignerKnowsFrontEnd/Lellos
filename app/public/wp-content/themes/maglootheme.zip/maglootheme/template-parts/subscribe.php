<section class='subscribe'>
    <div class='container'>
        <div class='subscribe-grid'>
            <div class='subscribe-card'>
                <h3>Subscribe to get all the latest News and Offers.</h3>
                <?php echo do_shortcode('[contact-form-7 id="846" title="Subscribe"]'); ?>
            </div>
        </div>
    </div>
</section>