<?php
global $post;
get_header();
?>


    


<?php get_footer(); ?>